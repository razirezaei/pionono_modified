../../experiments/arvaniti_tma/experiments/cross_validation/pionono/run.sh
../../experiments/arvaniti_tma/experiments/cross_validation/confmat_global/run.sh
../../experiments/arvaniti_tma/experiments/cross_validation/confmat_pixel/run.sh
../../experiments/arvaniti_tma/experiments/cross_validation/punet/run.sh
../../experiments/arvaniti_tma/experiments/cross_validation/sup_a1/run.sh
../../experiments/arvaniti_tma/experiments/cross_validation/sup_a2/run.sh