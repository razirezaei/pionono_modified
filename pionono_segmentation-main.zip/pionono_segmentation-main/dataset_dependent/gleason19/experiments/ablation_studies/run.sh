./dataset_dependent/gleason19/experiments/ablation_studies/pionono_dim_4/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_dim_16/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_kl_0_001/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_kl_0_0001/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_s_post_4/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_s_post_16/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_s_prior_1/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_zlr_0_01/run.sh
./dataset_dependent/gleason19/experiments/ablation_studies/pionono_zlr_0_04/run.sh

