./dataset_dependent/gleason19/experiments/external_testing/pionono/run.sh
./dataset_dependent/gleason19/experiments/external_testing/punet/run.sh
./dataset_dependent/gleason19/experiments/external_testing/sup_staple/run.sh
./dataset_dependent/gleason19/experiments/external_testing/confmat_global/run.sh
./dataset_dependent/gleason19/experiments/external_testing/confmat_pixel/run.sh

