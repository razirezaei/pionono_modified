./dataset_dependent/gleason19/experiments/cross_validation/pionono/run.sh
./dataset_dependent/gleason19/experiments/cross_validation/punet/run.sh
./dataset_dependent/gleason19/experiments/cross_validation/sup_staple/run.sh
./dataset_dependent/gleason19/experiments/cross_validation/confmat_global/run.sh
./dataset_dependent/gleason19/experiments/cross_validation/confmat_pixel/run.sh

